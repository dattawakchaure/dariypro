# db_setup.py
import sqlite3

conn = sqlite3.connect('dairy.db')
cursor = conn.cursor()

cursor.execute("""CREATE TABLE IF NOT EXISTS farmers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    address TEXT,
    milk_type TEXT,
    rate REAL
)""")

cursor.execute("""CREATE TABLE IF NOT EXISTS milk_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    farmer_id INTEGER,
    date TEXT,
    liters REAL,
    fat REAL,
    rate REAL,
    FOREIGN KEY (farmer_id) REFERENCES farmers(id)
)""")

conn.commit()
conn.close()
print("✅ Tables created!")
