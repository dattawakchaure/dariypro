# gui_main.py
import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3
from datetime import datetime

conn = sqlite3.connect('dairy.db')
cursor = conn.cursor()

def add_farmer():
    name = name_entry.get()
    address = address_entry.get()
    milk_type = milk_type_var.get()
    rate = rate_entry.get()
    if not (name and rate):
        messagebox.showwarning("Missing Info", "Name and Rate are required.")
        return
    cursor.execute("INSERT INTO farmers (name, address, milk_type, rate) VALUES (?, ?, ?, ?)",
                   (name, address, milk_type, float(rate)))
    conn.commit()
    messagebox.showinfo("Success", "Farmer added!")
    name_entry.delete(0, tk.END)
    address_entry.delete(0, tk.END)
    rate_entry.delete(0, tk.END)
    load_farmers()

def load_farmers():
    farmer_dropdown['menu'].delete(0, 'end')
    cursor.execute("SELECT name FROM farmers")
    all_names = [row[0] for row in cursor.fetchall()]
    for name in all_names:
        farmer_dropdown['menu'].add_command(label=name, command=tk._setit(farmer_name_var, name))
    if all_names:
        farmer_name_var.set(all_names[0])

def record_milk():
    name = farmer_name_var.get()
    cursor.execute("SELECT id, rate FROM farmers WHERE name = ?", (name,))
    row = cursor.fetchone()
    if not row:
        messagebox.showerror("Error", "Farmer not found.")
        return
    farmer_id, rate = row
    try:
        liters = float(liters_entry.get())
        fat = float(fat_entry.get())
        date = datetime.now().strftime("%Y-%m-%d")
        cursor.execute("INSERT INTO milk_records (farmer_id, date, liters, fat, rate) VALUES (?, ?, ?, ?, ?)",
                       (farmer_id, date, liters, fat, rate))
        conn.commit()
        messagebox.showinfo("Recorded", "Milk recorded.")
        liters_entry.delete(0, tk.END)
        fat_entry.delete(0, tk.END)
    except ValueError:
        messagebox.showerror("Input Error", "Enter valid liters and fat values.")

def generate_bill():
    name = farmer_name_var.get()
    cursor.execute("SELECT id, rate FROM farmers WHERE name = ?", (name,))
    row = cursor.fetchone()
    if not row:
        messagebox.showerror("Error", "Farmer not found.")
        return
    farmer_id, rate = row
    cursor.execute("SELECT SUM(liters) FROM milk_records WHERE farmer_id = ?", (farmer_id,))
    total = cursor.fetchone()[0] or 0
    amount = total * rate
    cursor.execute("SELECT address, milk_type FROM farmers WHERE id = ?", (farmer_id,))
    addr, mtype = cursor.fetchone()
    generate_pdf_bill(name, addr, mtype, total, rate, amount)

def show_report():
    for row in report_table.get_children():
        report_table.delete(row)
    cursor.execute("""
        SELECT f.name, f.address, f.milk_type, m.date, m.liters, m.fat, m.rate, (m.liters * m.rate)
        FROM milk_records m
        JOIN farmers f ON f.id = m.farmer_id
        ORDER BY m.date DESC
    """)
    for row in cursor.fetchall():
        report_table.insert('', tk.END, values=row)

# GUI Setup
root = tk.Tk()
root.title("DairyPro Manager (Final GUI)")
root.geometry("1000x700")
root.configure(bg="#f0fff0")
font_big = ("Segoe UI", 14)

notebook = ttk.Notebook(root)
notebook.pack(fill="both", expand=True)

# Add Farmer Tab
tab1 = ttk.Frame(notebook)
notebook.add(tab1, text="➕ Add Farmer")

frame1 = tk.Frame(tab1, bg="#f0fff0")
frame1.place(relx=0.5, rely=0.2, anchor='n')

tk.Label(frame1, text="Name", font=font_big).grid(row=0, column=0, padx=10, pady=10)
tk.Label(frame1, text="Address", font=font_big).grid(row=1, column=0, padx=10, pady=10)
tk.Label(frame1, text="Milk Type", font=font_big).grid(row=2, column=0, padx=10, pady=10)
tk.Label(frame1, text="Rate (₹/L)", font=font_big).grid(row=3, column=0, padx=10, pady=10)

name_entry = tk.Entry(frame1, font=font_big)
address_entry = tk.Entry(frame1, font=font_big)
milk_type_var = tk.StringVar(value="Cow")
milk_type_menu = ttk.OptionMenu(frame1, milk_type_var, "Cow", "Cow", "Buffalo")
rate_entry = tk.Entry(frame1, font=font_big)

name_entry.grid(row=0, column=1)
address_entry.grid(row=1, column=1)
milk_type_menu.grid(row=2, column=1)
rate_entry.grid(row=3, column=1)

tk.Button(frame1, text="Add Farmer", font=font_big, command=add_farmer).grid(row=4, column=0, columnspan=2, pady=20)

# Record Milk Tab
tab2 = ttk.Frame(notebook)
notebook.add(tab2, text="🥛 Record Milk")

tk.Label(tab2, text="Farmer Name", font=font_big).pack(pady=10)
farmer_name_var = tk.StringVar()
farmer_dropdown = ttk.OptionMenu(tab2, farmer_name_var, '')
farmer_dropdown.pack()

tk.Label(tab2, text="Liters", font=font_big).pack()
liters_entry = tk.Entry(tab2, font=font_big)
liters_entry.pack()

tk.Label(tab2, text="Fat %", font=font_big).pack()
fat_entry = tk.Entry(tab2, font=font_big)
fat_entry.pack()

tk.Button(tab2, text="Record Milk", font=font_big, command=record_milk).pack(pady=20)

# Billing Tab
tab3 = ttk.Frame(notebook)
notebook.add(tab3, text="💰 Billing")
tk.Label(tab3, text="Select Farmer (from Record Tab)", font=font_big).pack(pady=20)
tk.Button(tab3, text="🖨 Generate PDF Bill", font=font_big, command=generate_bill).pack(pady=20)

# Report Tab
tab4 = ttk.Frame(notebook)
notebook.add(tab4, text="📊 Report")

columns = ("Name", "Address", "MilkType", "Date", "Liters", "Fat", "Rate", "Total")
report_table = ttk.Treeview(tab4, columns=columns, show="headings")
for col in columns:
    report_table.heading(col, text=col)
    report_table.column(col, width=120)
report_table.pack(fill="both", expand=True, padx=10, pady=10)

tk.Button(tab4, text="Show Report", font=font_big, command=show_report).pack(pady=10)

load_farmers()
root.mainloop()


def generate_pdf_bill(farmer_name, address, milk_type, liters, rate, amount):
    filename = f"bill_{farmer_name.replace(' ', '_')}.pdf"
    c = canvas.Canvas(filename, pagesize=A4)
    text = c.beginText(50, 800)
    text.setFont("Helvetica", 14)
    text.textLine("DairyPro Milk Bill")
    text.textLine("----------------------------")
    text.textLine(f"Farmer: {farmer_name}")
    text.textLine(f"Address: {address}")
    text.textLine(f"Milk Type: {milk_type}")
    text.textLine(f"Rate: ₹{rate}/litre")
    text.textLine(f"Total Milk: {liters:.2f} litres")
    text.textLine(f"Total Amount: ₹{amount:.2f}")
    text.textLine(f"Date: {datetime.now().strftime('%Y-%m-%d')}")
    c.drawText(text)
    c.save()
    messagebox.showinfo("PDF Saved", f"PDF bill saved as {filename}")
