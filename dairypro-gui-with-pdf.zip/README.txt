DairyPro Manager – GUI Upgraded (Tkinter)

🧾 How to Run:
1. Open this folder in VS Code or Terminal
2. Run this once:
   python db_setup.py
3. Then start the GUI:
   python gui_main.py

✅ Features:
- Add farmer (name, address, milk type, rate)
- Record milk (dropdown selection, date auto)
- Billing: calculate total payment
- Excel-style report (date, liters, fat, rate, total ₹)
- All data stored in SQLite locally
